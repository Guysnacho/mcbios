# 2024 Requirements

Building the Conference Site

## Pages

[x] - Navbar
[x] - Footer
[x] - Home
   [x] - Banner
   [x] - New theme (motto for the year)
   [x] - Key dates
   [x] - Prezi address
[ ] - Abstract Submission - [TBD]
[ ] - Registration - [TBD]
[ ] - Accomodations - [TBD]
[ ] - Program - [TBD]
[-] - About Us
[ ] - Young Scientist Excellence Awards - [TBD]

## Steve Asks

1. Build placeholder site
   1. date and location
   2. For information that is not yet decided, put TBA. This applies to registration, key dates and programs etc.

2. board of directors page <https://www.mcbios.com/board-of-directors/>
   1. Update Dr. Qianqian Song's affiliation to "University of Florida"?

3. Connect with Emory RSPH IT
